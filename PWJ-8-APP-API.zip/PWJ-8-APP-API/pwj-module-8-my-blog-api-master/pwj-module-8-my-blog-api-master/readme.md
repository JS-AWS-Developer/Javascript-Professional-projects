# My Blog API

## Initialization

Clone the repository into a folder

    git clone https://github.com/CleverProgrammers/pwj-module-8-my-blog-api.git

Install NodeJS from this [LINK](https://nodejs.org/en/)

Navigate to `exercise` folder

Open Terminal

    npm init
    npm install --save express
    npm install --save multer
    npm install -g nodemon

Create `app.js` file    





